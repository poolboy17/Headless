const v1 = {};
const v2 = {};

const deprecated = [v2, v1];

export default deprecated;
