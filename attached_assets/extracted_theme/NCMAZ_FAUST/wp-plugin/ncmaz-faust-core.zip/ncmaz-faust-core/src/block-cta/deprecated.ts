import attributes from "./attributes";
import save from "./save";

const v1 = {
	attributes,
	save,
};
const v2 = {
	attributes,
	save,
};

const deprecated = [v2, v1];

export default deprecated;
