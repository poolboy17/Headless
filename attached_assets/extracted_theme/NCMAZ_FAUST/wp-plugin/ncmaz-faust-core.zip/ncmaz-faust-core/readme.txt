=== Ncmaz Faust Core ===
Contributors:      BooliiTheme
Tags:              block, ncmaz, ncmaz faust, nextjs headless, wordpress cms, faustjs, ncmaz headless, ncmaz nextjs, wordpress headless
Tested up to:      6.7.1
Stable tag:        2.8.1
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

The core plugin of the Ncmaz Faustjs headless WordPress theme - https://themeforest.net/item/ncmaz-nextjs-headless-wordpress-blog-magazine/47815656
 